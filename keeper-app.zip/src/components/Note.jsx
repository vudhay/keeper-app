import React from "react";
import note from "./Constnote";
function Note(Props) {
  return (
    <div className="note">
      {Props.name}
      <p>{Props.phone}</p>
      <p>{Props.email}</p>
    </div>
  );
}
note.map(Note);
export default Note;
