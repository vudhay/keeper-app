const note = [
  {
    name: "vudhay",
    phone: "8074825547",
    email: "pasupulavudhay4754@gmail.com"
  },
  {
    name: "vudhay",
    phone: "8074825547",
    email: "pasupulavudhay4754@gmail.com"
  },
  {
    name: "vudhay",
    phone: "8074825547",
    email: "pasupulavudhay4754@gmail.com"
  },
  {
    name: "vudhay",
    phone: "8074825547",
    email: "pasupulavudhay4754@gmail.com"
  }
];
export default note;
