import React from "react";
import Footer from "./Footer";
import Note from "./Note.jsx";
import Constnote from "./Constnote";

function createNotes(noteItem) {
  return (
    <Note name={noteItem.name} phone={noteItem.phone} email={noteItem.email} />
  );
}
function Header() {
  return (
    <div>
      <header>
        <h1>Keeper app</h1>
      </header>
      <footer>
        <Footer />
      </footer>
      {Constnote.map(createNotes)}
    </div>
  );
}
export default Header;
