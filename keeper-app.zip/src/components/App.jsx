import React from "react";
import Header from "./Header.jsx";
function App() {
  return <Header />;
}
export default App;
